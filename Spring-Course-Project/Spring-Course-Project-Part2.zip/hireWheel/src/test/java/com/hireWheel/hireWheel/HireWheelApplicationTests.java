package com.hireWheel.hireWheel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HireWheelApplicationTests {

	@Test
	void contextLoads() {
	}

}

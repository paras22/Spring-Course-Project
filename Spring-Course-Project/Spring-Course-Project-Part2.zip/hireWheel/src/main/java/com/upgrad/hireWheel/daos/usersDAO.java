package com.upgrad.hireWheel.daos;

import com.upgrad.hireWheel.entities.Users;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository("usersDAO")
public interface usersDAO extends JpaRepository<Users, Integer> {
    Users saveUsers(Users users);
    Users findByEmail(String email);
    Users findByEmailAndPassword(String email, String password);
    Users FindByMobileNumber(int MobileNumber);



}

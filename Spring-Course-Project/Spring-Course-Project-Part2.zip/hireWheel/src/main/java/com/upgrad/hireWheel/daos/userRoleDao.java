package com.upgrad.hireWheel.daos;

import com.upgrad.hireWheel.entities.userRole;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface userRoleDao extends JpaRepository<userRole, Integer> {
    userRole findByRoleId(int roleId);

}

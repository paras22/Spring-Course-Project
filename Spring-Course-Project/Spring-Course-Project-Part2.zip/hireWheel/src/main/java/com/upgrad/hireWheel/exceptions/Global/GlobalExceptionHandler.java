package com.upgrad.hireWheel.exceptions.Global;

import com.upgrad.hireWheel.Response.customResponse;
import com.upgrad.hireWheel.exceptions.UserNotFoundException;
import com.upgrad.hireWheel.exceptions.apiException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import static org.springframework.http.HttpStatus.BAD_REQUEST;
import static org.springframework.http.HttpStatus.UNAUTHORIZED;


import java.util.Date;


@ControllerAdvice
public class GlobalExceptionHandler extends Exception{

    private static final Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    @ExceptionHandler({RuntimeException.class})
    public ResponseEntity<Object> handleRunTimeException(RuntimeException RuntimeException) {
        return error(BAD_REQUEST, RuntimeException);
    }

    @ExceptionHandler(UserNotFoundException.class)
    public ResponseEntity<Object> handleUserNotFoundException(UserNotFoundException RuntimeException) {
        return error(UNAUTHORIZED, RuntimeException);
    }

    @ExceptionHandler(apiException.class)
    public ResponseEntity<Object> handleAPIException(apiException RuntimeException) {
        return error(BAD_REQUEST, RuntimeException);
    }


    private ResponseEntity error(HttpStatus status, Exception RuntimeException) {
        logger.error("Exception : ", RuntimeException);
        customResponse customResponse = new customResponse(new Date(), RuntimeException.getMessage(), status.value());
        return new ResponseEntity(customResponse, status);
    }

}

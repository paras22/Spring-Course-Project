package com.upgrad.hireWheel.validators;

import com.upgrad.hireWheel.dtos.VehicleDTO;
import com.upgrad.hireWheel.dtos.availability;
import com.upgrad.hireWheel.exceptions.Global.GlobalExceptionHandler;
import com.upgrad.hireWheel.exceptions.apiException;
import org.springframework.beans.factory.annotation.Autowired;

public class statusValidatorImpl implements statusValidator {

    @Autowired
    VehicleDTO vehicleDTO;
    @Override
    public void validateChangeVehicleAvailability(availability availability, int vehicleId) throws GlobalExceptionHandler {
        if (vehicleId == 0){
            throw new apiException("Field Vehicle Id can't be empty");
        }
        if (availability.getUserId() == 0){
            throw new apiException("Field user Id can't be empty");
        }

    }

    @Override
    public void validateAddVehicleRequest(VehicleDTO vehicleDTO) throws GlobalExceptionHandler {
        if(vehicleDTO.getVehicle_Number() == null || vehicleDTO.getVehicle_Number().isEmpty() || vehicleDTO.getVehicle_modle() == null ||  vehicleDTO.getVehicle_Color() == null  ||vehicleDTO.getVehicle_Image() == null)
        {
            throw new apiException("Fields cannot be null or empty");
        }

    }


}

package com.upgrad.hireWheel.validators;

import com.upgrad.hireWheel.dtos.VehicleDTO;
import com.upgrad.hireWheel.dtos.availability;
import com.upgrad.hireWheel.exceptions.Global.GlobalExceptionHandler;

import java.util.Date;

public interface statusValidator {
    void validateChangeVehicleAvailability(availability availability, int vehicleId) throws GlobalExceptionHandler;
    void validateAddVehicleRequest(VehicleDTO vehicleDTO) throws GlobalExceptionHandler;

}

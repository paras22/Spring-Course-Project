package com.upgrad.hireWheel.validators;

import com.upgrad.hireWheel.dtos.BookingDTO;
import com.upgrad.hireWheel.exceptions.Global.GlobalExceptionHandler;
import com.upgrad.hireWheel.exceptions.apiException;

public class BookingValidatorImpl implements  BookingValidator {
    @Override
    public void validateBooking(BookingDTO vehicle) throws GlobalExceptionHandler {
        if (vehicle.getUserId() == 0 || vehicle.getAmount() == 0 || vehicle.getLocation_Id() == 0 || vehicle.getVehicle_Id() == 0) {
            throw new apiException("fields cannot be empty");
        }


    }

    @Override
    public void validBooking(int userId) {
        if (userId == 0) {
            throw new apiException("“Invalid  Id ");
        }
    }
}




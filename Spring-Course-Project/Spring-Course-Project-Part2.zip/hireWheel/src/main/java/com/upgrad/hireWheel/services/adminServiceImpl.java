package com.upgrad.hireWheel.services;
import com.upgrad.hireWheel.daos.VehicleDAO;
import com.upgrad.hireWheel.daos.usersDAO;
import com.upgrad.hireWheel.entities.VEHICLE;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class adminServiceImpl implements  adminService{


    @Autowired
    usersDAO userDAO;

    @Autowired
    private VehicleDAO vehicleDAO;

    @Override
    public VEHICLE RegisterVehicle(VEHICLE vehicle) {

        ApplicationContext applicationContext = new ClassPathXmlApplicationContext();
        VehicleDAO vehicleDAO = (VehicleDAO)applicationContext.getBean("VehicleDAO");

        if(vehicle.getAvailabilityStatus() == 0){

            vehicle.setAvailabilityStatus(1);
            System.out.println();
        }
        if (vehicle.getAvailabilityStatus()== 1)
            vehicle.setAvailabilityStatus(1);

        return vehicle;
    }

    @Override
    public VEHICLE ChangeAvailability(VEHICLE vehicle) {


        return vehicleDAO.save(vehicle);    }
}

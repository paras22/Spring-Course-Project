package com.upgrad.hireWheel.services;

import com.upgrad.hireWheel.daos.BookingDAO;
import com.upgrad.hireWheel.daos.LocationDAO;
import com.upgrad.hireWheel.daos.VehicleDAO;
import com.upgrad.hireWheel.daos.usersDAO;
import com.upgrad.hireWheel.dtos.BookingDTO;
import com.upgrad.hireWheel.entities.BOOKING;
import com.upgrad.hireWheel.entities.Users;
import org.springframework.beans.factory.annotation.Autowired;

public class BookingServiceImpl implements BookingService {
    @Autowired
    BookingDAO bookingDAO;

    @Autowired
    usersDAO userDAO;

    @Autowired
    LocationDAO locationDAO;

    @Autowired
    VehicleDAO vehicleDAO;

    @Override
    public BOOKING addBooking(BookingDTO bookingDTO) throws Exception {
        Users user = userDAO.findById(bookingDTO.getUserId()).get();
        if (user.getWallet_money() < bookingDTO.getAmount()) {
            throw new Exception("Insufficient Balance.Please Check With Admin.");
        }
        BOOKING booking = new BOOKING();
        booking.setBookingDate(bookingDTO.getBooking_Date());
        booking.setPickUpDate(bookingDTO.getPickup_Date());
        booking.setDropOffDate(bookingDTO.getDrop_off_Date());
        booking.setAmount(bookingDTO.getAmount());
        booking.setVehicle(vehicleDAO.findById(bookingDTO.getVehicle_Id()).get());
        booking.setLocation(locationDAO.findById(bookingDTO.getLocation_Id()).get());


        return bookingDAO.save(booking);
    }
}
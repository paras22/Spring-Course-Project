package com.upgrad.hireWheel.services;


import org.springframework.stereotype.Service;

@Service
public interface initService {

    void startapp();
}

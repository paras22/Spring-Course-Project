package com.upgrad.hireWheel;

import org.springframework.beans.factory.annotation.Autowired;
import com.upgrad.hireWheel.services.initService;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HireWheelApplication {

	public static void main(String[] args) {
		SpringApplication.run(HireWheelApplication.class, args);
	}





	@Autowired
	initService initService;

	public void startapp(String... args) throws Exception {
		initService.startapp();
	}
}

package com.upgrad.hireWheel.services;

import com.upgrad.hireWheel.daos.VehicleDAO;
import com.upgrad.hireWheel.daos.usersDAO;
import com.upgrad.hireWheel.dtos.VehicleDTO;
import com.upgrad.hireWheel.entities.VEHICLE;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.*;

public class VehicleServiceImpl implements  VehicleService {



    @Autowired
    VehicleDAO vehicleDAO;


    @Autowired
    VehicleDTO vehicleDTO;

    @Autowired
    usersDAO userDAO;






    @Override
    public List<VEHICLE> getAllVehicles() {
        return vehicleDAO.findAll();

    }

    @Override
    public List<VEHICLE> getAllVehicleByUserId(int userId) throws Exception {
        return new ArrayList<>();

    }

    @Override
    public List<VEHICLE> getAvailableVehicles(String categoryName, Date PickUpDate, Date DropDate, int LocationId) throws Exception {
        return new ArrayList<>();
    }
}

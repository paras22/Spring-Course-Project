package com.upgrad.hireWheel.services;

import com.upgrad.hireWheel.dtos.loginFunc;
import com.upgrad.hireWheel.dtos.passwordDTO;
import com.upgrad.hireWheel.dtos.userDTO;
import com.upgrad.hireWheel.entities.Users;
import com.upgrad.hireWheel.exceptions.Global.GlobalExceptionHandler;

public interface UserService {
    Users getUser(loginFunc loginFunc) throws Exception;
    Users CreateUser(userDTO userDTO) throws Exception, DuplicateUserDetailsException;


}

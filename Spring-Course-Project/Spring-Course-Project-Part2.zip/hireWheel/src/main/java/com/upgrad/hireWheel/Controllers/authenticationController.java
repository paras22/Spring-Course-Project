package com.upgrad.hireWheel.Controllers;


import com.upgrad.hireWheel.Response.customResponse;
import com.upgrad.hireWheel.dtos.userDTO;
import com.upgrad.hireWheel.entities.Users;
import com.upgrad.hireWheel.services.DuplicateUserDetailsException;
import com.upgrad.hireWheel.services.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;




@RestController
public class authenticationController {
    private static final Logger logger = LoggerFactory.getLogger(authenticationController.class);

    @Autowired
    UserService UserService;

    @Autowired
    com.upgrad.hireWheel.validators.userValidator userValidator;


    @PostMapping("/users")
    public ResponseEntity userSignUp(@RequestBody userDTO userDTO) throws Exception, DuplicateUserDetailsException {
        ResponseEntity responseEntity = null;
        userValidator.Signup(userDTO);
        Users functionReturn = UserService.CreateUser(userDTO);
        if (functionReturn != null) {
            customResponse response = new customResponse(new Date(), "User Successfully Signed Up", 200);
            responseEntity = new ResponseEntity(response, HttpStatus.OK);
        }
        return responseEntity;
    }

    }


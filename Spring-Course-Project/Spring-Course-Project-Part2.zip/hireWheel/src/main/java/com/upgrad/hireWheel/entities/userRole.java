package com.upgrad.hireWheel.entities;

import javax.persistence.*;
import java.util.List;

@Entity
public class userRole {
    @Id
    private int roleId;

    @Column(unique = true)
    private String roleName;

    @OneToMany(fetch = FetchType.LAZY)
    private List<Users> users;
}

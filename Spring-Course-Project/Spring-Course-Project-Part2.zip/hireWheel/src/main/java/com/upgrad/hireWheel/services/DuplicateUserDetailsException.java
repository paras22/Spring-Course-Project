package com.upgrad.hireWheel.services;

public class DuplicateUserDetailsException extends Throwable {
    public DuplicateUserDetailsException(String email_already_exists) {
    }
}

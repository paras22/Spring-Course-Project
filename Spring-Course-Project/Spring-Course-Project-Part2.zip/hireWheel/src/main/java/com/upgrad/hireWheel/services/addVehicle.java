package com.upgrad.hireWheel.services;

import com.upgrad.hireWheel.dtos.VehicleDTO;
import com.upgrad.hireWheel.entities.VEHICLE;

public interface addVehicle {
    VEHICLE addVehicleRequest(VehicleDTO vehicle);

}

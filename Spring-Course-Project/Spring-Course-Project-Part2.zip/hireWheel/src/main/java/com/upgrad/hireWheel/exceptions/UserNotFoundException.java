package com.upgrad.hireWheel.exceptions;

public class UserNotFoundException  extends  RuntimeException{
    public UserNotFoundException(String ex)
    {
        super(ex);
    }
}

package com.upgrad.hireWheel.services;

import com.upgrad.hireWheel.entities.VEHICLE;

import java.util.Date;
import java.util.List;

public interface VehicleService {
    List<VEHICLE> getAllVehicles();


    List<VEHICLE> getAllVehicleByUserId(int userId) throws Exception;

    List<VEHICLE> getAvailableVehicles(String categoryName, Date PickUpDate, Date DropDate, int LocationId) throws Exception;
}

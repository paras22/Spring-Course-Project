package com.upgrad.hireWheel.dtos;

public class VehicleDTO {
    int vehicle_id  ;

    public int getVehicle_id() {
        return vehicle_id;
    }

    public void setVehicle_id(int vehicle_id) {
        this.vehicle_id = vehicle_id;
    }

    public String getVehicle_modle() {
        return Vehicle_modle;
    }

    public void setVehicle_modle(String vehicle_modle) {
        Vehicle_modle = vehicle_modle;
    }

    public String getVehicle_Color() {
        return Vehicle_Color;
    }

    public void setVehicle_Color(String vehicle_Color) {
        Vehicle_Color = vehicle_Color;
    }

    public String getVehicle_Number() {
        return Vehicle_Number;
    }

    public void setVehicle_Number(String vehicle_Number) {
        Vehicle_Number = vehicle_Number;
    }

    public String getVehicle_Image() {
        return Vehicle_Image;
    }

    public void setVehicle_Image(String vehicle_Image) {
        Vehicle_Image = vehicle_Image;
    }

    String Vehicle_modle, Vehicle_Color , Vehicle_Number, Vehicle_Image;
}

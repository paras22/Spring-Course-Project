package com.upgrad.hireWheel.services;

import com.upgrad.hireWheel.entities.VEHICLE;

public interface adminService {
    VEHICLE RegisterVehicle(VEHICLE vehicle);
    VEHICLE ChangeAvailability(VEHICLE vehicle);



}

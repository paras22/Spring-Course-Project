package com.upgrad.hireWheel.Response;

import java.util.Date;

public class customResponse {
    private Date Time;
    private String Message;
    private int Status;

    public customResponse(Date timestamp, String message, int statusCode) {
        super();
        this.Time = timestamp;
        this.Message = message;
        this.Status = statusCode;
    }
}

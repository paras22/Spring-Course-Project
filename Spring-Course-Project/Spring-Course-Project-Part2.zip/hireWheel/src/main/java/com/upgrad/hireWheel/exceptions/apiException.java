package com.upgrad.hireWheel.exceptions;

public class apiException  extends  RuntimeException{
    public  apiException(String ex){
        super(ex);
    }
}

package com.upgrad.hireWheel.validators;

import com.upgrad.hireWheel.dtos.passwordDTO;
import com.upgrad.hireWheel.dtos.userDTO;
import com.upgrad.hireWheel.exceptions.Global.GlobalExceptionHandler;

public interface userValidator {

    void Signup(userDTO userDTO) throws GlobalExceptionHandler;
    void validateChangePassword(passwordDTO Users) throws  GlobalExceptionHandler;
}

package com.upgrad.hireWheel.validators;

import com.upgrad.hireWheel.dtos.BookingDTO;
import com.upgrad.hireWheel.exceptions.Global.GlobalExceptionHandler;

public interface BookingValidator {
    void validateBooking(BookingDTO vehicle) throws GlobalExceptionHandler;
    void validBooking(int id);


}

package com.upgrad.hireWheel.services;

import com.upgrad.hireWheel.daos.userRoleDao;
import com.upgrad.hireWheel.daos.usersDAO;
import com.upgrad.hireWheel.dtos.loginFunc;
import com.upgrad.hireWheel.dtos.passwordDTO;
import com.upgrad.hireWheel.dtos.userDTO;
import com.upgrad.hireWheel.entities.Users;
import com.upgrad.hireWheel.exceptions.Global.GlobalExceptionHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("UserService")
public class UserServiceImpl implements UserService {
    @Autowired
    usersDAO usersDAO;

    @Autowired
    userRoleDao userRoleDao;



    @Override
    public Users getUser(loginFunc loginFunc) throws  Exception{
        if (usersDAO.findByEmail(loginFunc.getEmail()) == null) {
            throw  new Exception("User not Registered");
        }
        if (usersDAO.findByEmail(loginFunc.getPassword()) == null) {
            throw  new Exception("Unauthorized User");

        }

        return usersDAO.findByEmailAndPassword(loginFunc.getEmail(), loginFunc.getPassword() );
    }




    @Override
    public Users CreateUser(userDTO userDTO) throws Exception, DuplicateUserDetailsException {
        if (usersDAO.findByEmail(userDTO.getEmail()) != null) {
            throw new DuplicateUserDetailsException("Email already exists");
        }

        if (usersDAO.FindByMobileNumber(Integer.parseInt(userDTO.getMobileNo())) != null) {
            throw new DuplicateUserDetailsException("Mobile number already exists");
        }
        Users user = new Users();
        user.setFirst_name(userDTO.getFirstName());
        user.setFirst_name(userDTO.getLastName());
        user.setMobile_no(Integer.parseInt(userDTO.getMobileNo()));
        user.setEmail(userDTO.getEmail());
        user.setPassword(userDTO.getPassword());
        user.setWallet_money(userDTO.getWalletMoney());
        user.setUserRole(userRoleDao.findByRoleId(2));


        return usersDAO.saveUsers(user);
    }
    }


package com.upgrad.hireWheel.validators;

import com.upgrad.hireWheel.dtos.passwordDTO;
import com.upgrad.hireWheel.dtos.userDTO;
import com.upgrad.hireWheel.entities.Users;
import com.upgrad.hireWheel.exceptions.Global.GlobalExceptionHandler;
import com.upgrad.hireWheel.exceptions.apiException;
import org.springframework.stereotype.Service;


@Service
public class userValidatorImpl  implements  userValidator{






    @Override
    public void Signup(userDTO userDTO) throws GlobalExceptionHandler {
        if(userDTO.getFirstName() ==null || userDTO.getFirstName() == ""){
            throw new apiException("Field first name  cannot be null or empty");
        }
        if (userDTO.getPassword() == "" || userDTO.getPassword() ==null || userDTO.getPassword().length()<5){
            throw new apiException("Field password cannot be null");
        }

        if (userDTO.getMobileNo() == null || userDTO.getMobileNo().length()<10 || userDTO.getMobileNo().length()>10){
            throw new apiException("Field mobile number cannot be null and must be valid");
        }


    }

    @Override
    public void validateChangePassword(passwordDTO users) throws GlobalExceptionHandler {
        if ( users.getPassword() ==null || users.getPassword().isEmpty() ||users.getPassword().length()<5){
            throw new apiException("Password cannot be null or empty or less than 5 characters");

        }else if (users.getMobileNo() == null ||users.getMobileNo().isEmpty() ||  users.getMobileNo().length()<10 || users.getMobileNo().length()>10){
            throw new apiException("Mobile Number cannot be null or empty and must be 10 digits");
        }



    }
}

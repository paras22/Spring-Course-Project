package com.upgrad.hireWheel.Controllers;


import com.upgrad.hireWheel.dtos.BookingDTO;
import com.upgrad.hireWheel.entities.BOOKING;
import com.upgrad.hireWheel.exceptions.Global.GlobalExceptionHandler;
import com.upgrad.hireWheel.services.BookingService;
import com.upgrad.hireWheel.validators.BookingValidator;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.logging.Logger;

public class BookingController {

    @Autowired
    BookingService bookingService;

    @Autowired
    BookingValidator bookingValidator;


    private static final Logger logger = (Logger) LoggerFactory.getLogger(BookingController.class);

    @PostMapping("/bookings")
    public ResponseEntity addBooking(@RequestBody BookingDTO bookingDTO) {
        ResponseEntity responseEntity = null;
        try {
            bookingValidator.validateBooking(bookingDTO);
            BOOKING responseBooking = bookingService.addBooking(bookingDTO);
            responseEntity = ResponseEntity.ok(responseBooking);
        } catch (GlobalExceptionHandler e) {
        } catch (Exception e) {
            e.printStackTrace();
        }
        return responseEntity;


    }
}

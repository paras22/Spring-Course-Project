package com.upgrad.hireWheel.Controllers;

public class adminController {
}

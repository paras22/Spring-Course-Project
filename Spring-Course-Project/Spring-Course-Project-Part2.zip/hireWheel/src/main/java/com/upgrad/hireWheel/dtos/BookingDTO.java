package com.upgrad.hireWheel.dtos;

import java.util.Date;

public class BookingDTO {
    int userId;
    int Vehicle_Id;
    Date Pickup_Date;
    Date drop_off_Date;
    Date Booking_Date;
    int Location_Id;
    int amount;

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getVehicle_Id() {
        return Vehicle_Id;
    }

    public void setVehicle_Id(int vehicle_Id) {
        Vehicle_Id = vehicle_Id;
    }

    public Date getPickup_Date() {
        return Pickup_Date;
    }

    public void setPickup_Date(Date pickup_Date) {
        Pickup_Date = pickup_Date;
    }

    public Date getDrop_off_Date() {
        return drop_off_Date;
    }

    public void setDrop_off_Date(Date drop_off_Date) {
        this.drop_off_Date = drop_off_Date;
    }

    public Date getBooking_Date() {
        return Booking_Date;
    }

    public void setBooking_Date(Date booking_Date) {
        Booking_Date = booking_Date;
    }

    public int getLocation_Id() {
        return Location_Id;
    }

    public void setLocation_Id(int location_Id) {
        Location_Id = location_Id;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }
}

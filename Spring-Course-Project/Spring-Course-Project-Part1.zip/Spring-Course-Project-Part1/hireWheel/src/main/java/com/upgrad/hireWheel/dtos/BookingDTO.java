package com.upgrad.hireWheel.dtos;

import java.sql.Date;

public class BookingDTO {
    private int  userbookingId;
    private Date pickupDate;
    private Date dropoffDate;
    private Date bookingDate;
    private int amount;
    private int vehicleId;
    private int locationid;






    

    /**
     * @return int return the bookingId
     */
    public int getuserBookingId() {
        return userbookingId;
    }

    /**
     * @param bookingId the bookingId to set
     */
    public void setuserBookingId(int bookingId) {
        this.userbookingId = userbookingId;
    }

    /**
     * @return Date return the pickupDate
     */
    public Date getPickupDate() {
        return pickupDate;
    }

    /**
     * @param pickupDate the pickupDate to set
     */
    public void setPickupDate(Date pickupDate) {
        this.pickupDate = pickupDate;
    }

    /**
     * @return Date return the dropoffDate
     */
    public Date getDropoffDate() {
        return dropoffDate;
    }

    /**
     * @param dropoffDate the dropoffDate to set
     */
    public void setDropoffDate(Date dropoffDate) {
        this.dropoffDate = dropoffDate;
    }

    /**
     * @return Date return the bookingDate
     */
    public Date getBookingDate() {
        return bookingDate;
    }

    /**
     * @param bookingDate the bookingDate to set
     */
    public void setBookingDate(Date bookingDate) {
        this.bookingDate = bookingDate;
    }

    /**
     * @return int return the amount
     */
    public int getAmount() {
        return amount;
    }

    /**
     * @param amount the amount to set
     */
    public void setAmount(int amount) {
        this.amount = amount;
    }

    /**
     * @return int return the vehicleId
     */
    public int getVehicleId() {
        return vehicleId;
    }

    /**
     * @param vehicleId the vehicleId to set
     */
    public void setVehicleId(int vehicleId) {
        this.vehicleId = vehicleId;
    }

    /**
     * @return int return the locationid
     */
    public int getLocationid() {
        return locationid;
    }

    /**
     * @param locationid the locationid to set
     */
    public void setLocationid(int locationid) {
        this.locationid = locationid;
    }

}

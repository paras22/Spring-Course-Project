package com.upgrad.hireWheel.services;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import com.upgrad.hireWheel.daos.VehicleDAO;
import com.upgrad.hireWheel.daos.usersDAO;
import com.upgrad.hireWheel.entities.Users;
import com.upgrad.hireWheel.entities.VEHICLE;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service("VehicleService")

public class VehicleServiceImpl implements VehicleService {

    @Autowired
    usersDAO usersDAO;

    @Autowired
    VehicleDAO VehicleDAO;

    @Override
    public List<VEHICLE> getAllVehicle() {


        return VehicleDAO.findAll();
    }

    @Override
    public List<VEHICLE> getAllVehicles(String CategoryName, Date PickUpDate, Date DropDate, int LocationId)
            throws Exception {


        return new ArrayList<>();
    }

    @Override
    public List<VEHICLE> getAllVehicle(int userId) throws Exception {
        Optional<Users> user;
        user = usersDAO.findById(userId);
        Users users = user.orElseThrow(()->new Exception("User Not Found "));
        return users.getVehicle();
    }

    
}

package com.upgrad.hireWheel.dtos;

public class UserDTO {
    String first_name;
    String last_name;
    String email;
    String password;
    String mobile_no;
    double wallet_money;
    int userRoleId;
    
}

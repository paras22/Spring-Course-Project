package com.upgrad.hireWheel.services;

import com.upgrad.hireWheel.daos.VehicleDAO;
import com.upgrad.hireWheel.entities.VEHICLE;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class adminServiceImpl implements AdminService {

    @Autowired
    VehicleDAO VehicleDAO;

    @Override
    public VEHICLE changeAvailability(VEHICLE vehicle) {
        if (vehicle.getAvailabilityStatus() == 0) {
        
            vehicle.setAvailabilityStatus(1);

        }
        
    else{
        vehicle.setAvailabilityStatus(0);
    }
        return vehicle;
    }

    @Override
    public VEHICLE registration(VEHICLE vehicle) throws Exception {  

        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("HireWheels.xml");
        VehicleDAO vehicleDAO = (VehicleDAO)applicationContext.getBean("VehicleDAO");
    return VehicleDAO.save(vehicle);
    }
    
}

package com.upgrad.hireWheel.services;

import com.upgrad.hireWheel.daos.BookingDAO;
import com.upgrad.hireWheel.daos.LocationDAO;
import com.upgrad.hireWheel.daos.VehicleDAO;
import com.upgrad.hireWheel.daos.usersDAO;
import com.upgrad.hireWheel.dtos.BookingDTO;
import com.upgrad.hireWheel.entities.BOOKING;
import com.upgrad.hireWheel.entities.Users;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * BookingServiceImpl
 */

@Service("BookingService")
public class BookingServiceImpl implements BookingService {

    @Autowired
    usersDAO usersDAO;

    @Autowired
    VehicleDAO VehicleDAO;


    @Autowired
    LocationDAO LocationDAO;

    @Autowired
    BookingDTO BookingDTO;

    @Autowired
    BookingDAO BookingDAO;

    @Override
    public BOOKING addBooking(BookingDTO bookingDTO) throws Exception {

        Users users = usersDAO.findById(bookingDTO.getuserBookingId()).get();
        if (users.getWallet_money() < bookingDTO.getAmount()) {
            throw new Exception("Insufficient Balance. Please Check With Admin" );
        }
        BOOKING booking = new BOOKING();
        booking.setBookingDate(bookingDTO.getBookingDate());
        booking.setPickUpDate(bookingDTO.getPickupDate());
        booking.setDropOffDate(bookingDTO.getDropoffDate());
        booking.setAmount(bookingDTO.getAmount());
        booking.setVehicle(VehicleDAO.findById(bookingDTO.getVehicleId()).get());
        booking.setLocation(LocationDAO.findById(bookingDTO.getuserBookingId()).get());
        return BookingDAO.save(booking);
        

        
        
    }

    
}
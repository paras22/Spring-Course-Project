package com.upgrad.hireWheel.services;

import com.upgrad.hireWheel.entities.VEHICLE;

/**
 * AdminService
 */
public interface AdminService {

    VEHICLE changeAvailability(VEHICLE vehicle);
    VEHICLE registration(VEHICLE vehicle) throws Exception;


}
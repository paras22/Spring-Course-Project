package com.upgrad.hireWheel.services;

import java.util.Date;
import java.util.List;

import com.upgrad.hireWheel.entities.VEHICLE;

public interface VehicleService {
    List<VEHICLE> getAllVehicle();
    List<VEHICLE> getAllVehicles (String CategoryName, Date PickUpDate, Date DropDate, int LocationId) throws Exception;
    List<VEHICLE> getAllVehicle(int userId) throws Exception;


}

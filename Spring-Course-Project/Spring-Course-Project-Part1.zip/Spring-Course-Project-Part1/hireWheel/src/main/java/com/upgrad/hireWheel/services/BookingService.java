package com.upgrad.hireWheel.services;

import com.upgrad.hireWheel.dtos.BookingDTO;
import com.upgrad.hireWheel.entities.BOOKING;

public interface BookingService {
    BOOKING addBooking(BookingDTO bookingDTO) throws Exception;
    
}
